create view V_LOCATION_SYSTEM as
select `eam_dev`.`EAM_LOCATION`.`ID`                        AS `ID`,
       `eam_dev`.`EAM_LOCATION_SYSTEM`.`ADDRESS`            AS `ADDRESS`,
       `eam_dev`.`EAM_LOCATION_SYSTEM`.`ASSET_HEALTH`       AS `ASSET_HEALTH`,
       `eam_dev`.`EAM_LOCATION_SYSTEM`.`CLASS_STRUCTURE_ID` AS `CLASS_STRUCTURE_ID`,
       `eam_dev`.`EAM_LOCATION_SYSTEM`.`DESCRIPTION`        AS `DESCRIPTION`,
       `eam_dev`.`EAM_LOCATION_SYSTEM`.`DOC_TYPE`           AS `DOC_TYPE`,
       `eam_dev`.`EAM_LOCATION_SYSTEM`.`NETWORK`            AS `NETWORK`,
       `eam_dev`.`EAM_LOCATION_SYSTEM`.`ORG_ID`             AS `ORG_ID`,
       `eam_dev`.`EAM_LOCATION_SYSTEM`.`PRIMARY_SYSTEM`     AS `PRIMARY_SYSTEM`,
       `eam_dev`.`EAM_LOCATION_SYSTEM`.`SITE_ID`            AS `SITE_ID`,
       `eam_dev`.`EAM_LOCATION_SYSTEM`.`SYSTEM_ID`          AS `SYSTEM_ID`,
       `eam_dev`.`EAM_LOCATION`.`LOCATION_ID`               AS `LOCATION_ID`
from (`eam_dev`.`EAM_LOCATION_SYSTEM`
         join `eam_dev`.`EAM_LOCATION`)
where (exists(select 1
              from `eam_dev`.`EAM_LOCATION_HIERARCHY`
              where ((`eam_dev`.`EAM_LOCATION_SYSTEM`.`SYSTEM_ID` = `eam_dev`.`EAM_LOCATION_HIERARCHY`.`SYSTEM_ID`) and
                     (`eam_dev`.`EAM_LOCATION_SYSTEM`.`SITE_ID` = `eam_dev`.`EAM_LOCATION_HIERARCHY`.`SITE_ID`) and
                     (`eam_dev`.`EAM_LOCATION_HIERARCHY`.`LOCATION_ID` = `eam_dev`.`EAM_LOCATION`.`LOCATION_ID`))) and
       (`eam_dev`.`EAM_LOCATION_SYSTEM`.`SITE_ID` = `eam_dev`.`EAM_LOCATION`.`SITE_ID`));


create view V_DRILL_DOWN as
select `A`.`LOC_VALUE` AS `LOC_VALUE`,
       `A`.`SITE_ID`   AS `SITE_ID`,
       `B`.`SYSTEM_ID` AS `SYSTEM_ID`,
       `C`.`PARENT`    AS `PARENT`
from (select `eam_dev`.`EAM_LOCATION`.`LOCATION_ID` AS `LOC_VALUE`, `eam_dev`.`EAM_LOCATION`.`SITE_ID` AS `SITE_ID`
      from `eam_dev`.`EAM_LOCATION`
      group by `eam_dev`.`EAM_LOCATION`.`LOCATION_ID`) `A`
         join `eam_dev`.`V_LOCATION_SYSTEM` `B`
         join `eam_dev`.`EAM_LOCATION_HIERARCHY` `C`
where ((`A`.`LOC_VALUE` = `B`.`LOCATION_ID`) and (`A`.`LOC_VALUE` = `C`.`LOCATION_ID`) and
       (`B`.`SYSTEM_ID` = `C`.`SYSTEM_ID`));


create view V_CLASSIFICATION as
select `eam_dev`.`SYS_CLASSIFICATION`.`ID`                  AS `ID`,
       `eam_dev`.`SYS_CLASSIFICATION`.`CLASSIFICATION_ID`   AS `CLASSIFICATION_ID`,
       `eam_dev`.`SYS_CLASSIFICATION`.`DESCRIPTION`         AS `DESCRIPTION`,
       `eam_dev`.`SYS_CLASSIFICATION`.`PARENT`              AS `PARENT`,
       `eam_dev`.`SYS_CLASSIFICATION`.`HIERARCHY_PATH`      AS `HIERARCHY_PATH`,
       `eam_dev`.`SYS_CLASSIFICATION`.`SEQ`                 AS `SEQ`,
       `eam_dev`.`SYS_CLASSIFICATION`.`ORG_ID`              AS `ORG_ID`,
       `eam_dev`.`SYS_CLASSIFICATION`.`SITE_ID`             AS `SITE_ID`,
       `eam_dev`.`SYS_CLASSIFICATION`.`HAS_CHILDREN`        AS `HAS_CHILDREN`,
       `eam_dev`.`SYS_CLASSIFICATION`.`ROWSTAMP`            AS `ROWSTAMP`,
       `eam_dev`.`SYS_CLASSIFICATION`.`HIERARCHY_PATH_DESC` AS `HIERARCHY_PATH_DESC`,
       `eam_dev`.`SYS_CLASS_USEWITH`.`TOP_LEVEL`            AS `TOP_LEVEL`,
       `eam_dev`.`SYS_CLASS_USEWITH`.`RBOSETINFO_NAME`      AS `RBOSETINFO_NAME`
from `eam_dev`.`SYS_CLASSIFICATION`
         join `eam_dev`.`SYS_CLASS_USEWITH`
where (`eam_dev`.`SYS_CLASSIFICATION`.`CLASSIFICATION_ID` = `eam_dev`.`SYS_CLASS_USEWITH`.`CLASSIFICATION_ID`);


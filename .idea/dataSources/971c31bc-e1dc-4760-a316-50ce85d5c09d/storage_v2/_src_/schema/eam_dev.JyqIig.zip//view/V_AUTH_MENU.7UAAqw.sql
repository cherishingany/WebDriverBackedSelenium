create view V_AUTH_MENU as
select `auth_app`.`AUTH_ID`              AS `AUTH_ID`,
       `eam_dev`.`UI_MENU`.`ID`          AS `ID`,
       `eam_dev`.`UI_MENU`.`NAME`        AS `NAME`,
       `eam_dev`.`UI_MENU`.`PARENT`      AS `PARENT`,
       `eam_dev`.`UI_MENU`.`ICON`        AS `ICON`,
       `eam_dev`.`UI_MENU`.`POSITION`    AS `POSITION`,
       `eam_dev`.`UI_MENU`.`APP_ID`      AS `APP_ID`,
       `eam_dev`.`UI_MENU`.`DESCRIPTION` AS `DESCRIPTION`,
       `eam_dev`.`UI_MENU`.`ROWSTAMP`    AS `ROWSTAMP`
from (`eam_dev`.`UI_MENU`
         join (select `eam_dev`.`SYS_AUTH_APP_SIGOPTION`.`APP_ID`  AS `APP_ID`,
                      `eam_dev`.`SYS_AUTH_APP_SIGOPTION`.`AUTH_ID` AS `AUTH_ID`
               from `eam_dev`.`SYS_AUTH_APP_SIGOPTION`
               where (`eam_dev`.`SYS_AUTH_APP_SIGOPTION`.`SIGOPTION_ID` = 'READ')
               group by `eam_dev`.`SYS_AUTH_APP_SIGOPTION`.`APP_ID`,
                        `eam_dev`.`SYS_AUTH_APP_SIGOPTION`.`AUTH_ID`) `auth_app`
              on ((`auth_app`.`APP_ID` = `eam_dev`.`UI_MENU`.`APP_ID`)));

